module.exports = function(req,res){
    res.render('topic.hbs');
};