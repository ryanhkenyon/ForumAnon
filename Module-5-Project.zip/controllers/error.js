module.exports = function(req,res){
    res.render('error.hbs');
};